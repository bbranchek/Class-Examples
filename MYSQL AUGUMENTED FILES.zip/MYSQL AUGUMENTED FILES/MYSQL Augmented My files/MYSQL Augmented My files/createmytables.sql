create table employees
(name char(15),department char(15),badge integer);
insert into employees
values ('Bob Smith','Sales',1234);
insert into employees
values ('Mary Smith','Sales',1235);
insert into employees
values ('Sue Simmons','Sales',1236);
create table pays
(badge integer,hours integer,rate integer);
insert into pays
values (1234,40,15);
insert into pays
values (1235,41,19);
insert into pays
values (1236,39,12);
select * from employees;
select * from pays;