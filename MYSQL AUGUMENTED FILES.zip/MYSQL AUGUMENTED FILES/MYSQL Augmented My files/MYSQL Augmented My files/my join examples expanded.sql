select name,department,hours,rate,employees.badge,pays.badge
from employees inner join pays
on employees.badge=pays.badge;

select name,department,hours,rate,employees.badge,pays.badge
from employees cross join pays;

insert into employees
values ('Fred Saunders','Sales',5555);

insert into pays
values (1111,39,19);

select name,department,hours,rate,employees.badge,pays.badge
from employees inner join pays
on employees.badge=pays.badge;


select name,department,hours,rate,employees.badge,pays.badge
from employees left outer join pays
on employees.badge=pays.badge;

select name,department,hours,rate,employees.badge,pays.badge
from employees right outer join pays
on employees.badge=pays.badge;

# not supported in any version of mysql
select name,department,hours,rate,employees.badge,pays.badge
from employees full outer join pays
on employees.badge=pays.badge;


# alternate to full outer join
select name,department,hours,rate,employees.badge,pays.badge
from employees left outer join pays
on employees.badge=pays.badge
UNION 
select name,department,hours,rate,employees.badge,pays.badge
from employees right outer join pays
on employees.badge=pays.badge;



select name,department,hours,rate,employees.badge,pays.badge
from employees left outer join pays
on employees.badge=pays.badge
where pays.badge is null;

select name,department,hours,rate,employees.badge,pays.badge
from employees left outer join pays
on employees.badge=pays.badge
where pays.badge = null;

create table third_table
(project char(15),years_working char(15),badge integer);

insert into third_table
values ('inventory','15',1234);

insert into third_table
values ('inventory','8',1235);

insert into third_table
values ('archive','11',1236);

select * from third_table;

select name,department,hours,rate,project,years_working,employees.badge,pays.badge,third_table.badge
from employees inner join pays
on employees.badge=pays.badge
inner join third_table
on third_table.badge=pays.badge;

