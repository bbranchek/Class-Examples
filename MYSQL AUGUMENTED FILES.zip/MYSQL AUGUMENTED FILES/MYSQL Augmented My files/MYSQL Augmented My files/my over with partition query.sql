SELECT 
    e.name,
    e.department,
    (p.hours * p.rate) AS individual_pay,
    SUM(p.hours * p.rate) OVER (PARTITION BY e.department) AS dept_total_pay,
    ROUND(
        ((p.hours * p.rate) / SUM(p.hours * p.rate) OVER (PARTITION BY e.department)) * 100, 
        2
    ) AS pct_of_dept_pay
FROM employees e
JOIN pays p ON e.badge = p.badge;
