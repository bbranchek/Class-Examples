WITH EmployeePay AS (
    SELECT 
        e.name,
        e.department,
        (p.hours * p.rate) AS total_pay
    FROM employees e
    JOIN pays p ON e.badge = p.badge
)
SELECT 
    name,
    department,
    total_pay,
    ROUND((total_pay / SUM(total_pay) OVER ()) * 100, 2) AS pct_of_company_pay
FROM EmployeePay;
