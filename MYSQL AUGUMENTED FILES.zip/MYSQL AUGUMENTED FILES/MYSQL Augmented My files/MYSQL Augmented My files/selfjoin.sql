CREATE TABLE selfjoin (
	fname nchar(10) NOT NULL,
	lname nchar(10) NOT NULL,
	badge int NOT NULL,
	managerid int NOT NULL);

	insert into selfjoin
values ('Bob ','Smith ',1234,1234);

insert into selfjoin
values  ('Mary      ','Smith     ',1235,1234);

insert into selfjoin
values ('Sue       ','Simmons   ',1236,1234);

insert into selfjoin
values ('Fred      ','Sanders   ',1237,1234);

insert into selfjoin
values ('Art       ','Shell     ',1238,1237);

insert into selfjoin
values ('Lou       ','Costello  ',1239,1237);


select e.fname,e.lname,e.badge, m.fname,m.lname,m.badge
from selfjoin e join selfjoin m
on e.badge = m.managerid;