def addtwo(x,y):
	result = x + y
	return result
if __name__ == "__main__":
	print('The two numbers are added together')

