more = "y" 
while more.lower() == "y": 
    miles_driven = float(input("Enter miles driven:\t\t")) 
    if miles_driven <= 0:
        print("must be greater than zero. Try again.\n") 
        continue
    while miles_driven > 0: 
        gallons_used = float(input("Enter gallons of gas used:\t")) 
        # validate input 
        if gallons_used <= 0: 
            print("gallons must be greater than zero. Try again.\n") 
            continue
        elif gallons_used > 0:
            break    
    mpg = round(miles_driven / gallons_used, 2) 
    print("Miles Per Gallon:", mpg, "\n") 
    more = input("Continue? (y/n): ") 
    print() 
print("Okay, bye!")