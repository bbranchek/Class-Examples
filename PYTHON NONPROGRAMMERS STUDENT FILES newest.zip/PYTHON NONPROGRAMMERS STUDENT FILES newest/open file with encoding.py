with open("pg244.txt", encoding="utf8") as file: 
    contents = file.read() 
    print(contents)



with open("pg244.txt", encoding="ansi") as file: 
    contents = file.read() 
    print(contents)