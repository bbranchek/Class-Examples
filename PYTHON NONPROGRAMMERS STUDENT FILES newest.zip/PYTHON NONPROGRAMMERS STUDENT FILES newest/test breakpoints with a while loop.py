#Set a breakpoint on the while clause (add line numbers first from Tools, Options, Editor) the double-click on the while line
#From the view menu add Variables
#Click on the bug icon to the right of the green arrow to go to debug mode
#The counter variable will be created wit ha value of 0 and stop on thwe while without executing it
#You should also see the variable counter with a value of 0 added to the Variables window
#Notice that the entire while loop is highlighted in yellow
#click once on the first downward arrow to the right of the bug icon on the toolbar
#The while loop will execute 5 times printing 0 t0 4 and stop at the next line the print
#Press the same arrow or F7 once more to execute the print statement
#Click on the STOP icon on the toolbar
#Run the program again by clicking on the bug icon
#Once again it will stop at the while line
#This time click on the second downward facing arrow step into
#This will allow you to execute each line within the while loop
#You will the value of counter change for 0 to 4 in the Variables windows
#and also in the shell window
#Keep clicking the step into or F7 until it exits the while loop
#Then use the step over of step into to execute the final print and end the program





counter = 0 
while counter < 5: 
    print(counter, end=" ") 
    counter += 1 
print("\nThe loop has ended.")