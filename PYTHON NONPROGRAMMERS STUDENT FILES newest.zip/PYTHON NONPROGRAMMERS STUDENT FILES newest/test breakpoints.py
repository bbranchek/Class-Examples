x=5
print(x)
y='sample data in a variable'
print(y)
print('data as a literal in print')
print(4 * 2)
