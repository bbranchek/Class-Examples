x = [1,2]
y = (x)
type(x)
type(y)
print(x)
print(y)
x=[45,34]
print(x)
print(y)