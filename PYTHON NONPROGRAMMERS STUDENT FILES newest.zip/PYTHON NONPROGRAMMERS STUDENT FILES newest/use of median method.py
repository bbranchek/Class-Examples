import statistics
print(statistics.median([90,80,70,70]))