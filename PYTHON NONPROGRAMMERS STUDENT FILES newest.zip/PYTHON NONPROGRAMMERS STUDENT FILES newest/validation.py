#!/usr/bin/env python3
 
 # add a function named get_float() which accepts  3 arguments
# The values entered must be great than the low value and less than or equal to the hight value
# The low and high values will be defined in the main module
# Return a message "Entry must be greater than 0 and less than or equal to the high value"
# The prompt value will be passed a a parameter value when get_float() is called in the main module

# The following code is the completed function so you do nor have to write it

def get_float(prompt, low, high):
    while True:
        number = float(input(prompt))
        if number > low and number <= high:
            is_valid = True
            return number
        else:
            print("Entry must be greater than", low,
                  "and less than or equal to", high,
                  "Please try again.")

 
# Write a second function using the description in step 8
# It be identical to the previous get_float() function except the input value
# should should be converted to an integer value rather than a floating point value
            
# Leave the following code unchanged

def main():
    choice = "y"
    while choice.lower() == "y":
        # get input
        valid_number = get_float("Enter number: ", 0, 1000)
        print("Valid number = ", valid_number)
        print()
        valid_integer = get_int("Enter integer: ", 0, 50)      
        print("Valid integer = ", valid_integer)
        print()

        # see if the user wants to continue
        choice = input("Repeat? (y/n): ")
        print()

    print("Bye!")
    
if __name__ == "__main__":
    main()
