def addtwo(x,y):
	result = x + y
	return result
print('The two numbers are added together')

