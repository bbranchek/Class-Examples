-- Step 2 query
CREATE INDEX idx_cust
ON Customers (city, state)
GO
-- Step 3 query
sp_help Customers
GO
-- Step 4 query
DROP INDEX Customers.idx_cust
GO
-- Step 5 query
sp_help Customers
