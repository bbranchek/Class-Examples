/* -------------------------------------------------------
LESSON: Indexing Data
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 5-1 Step 2a ------------ */
CREATE NONCLUSTERED INDEX idx_title
ON Titles(bktitle, slprice)
GO

/* ------------ SNIPPET: Activity 5-1 Step 2c ------------ */
sp_help Titles
GO

/* ------------ SNIPPET: Activity 5-1 Step 3a ------------ */
CREATE NONCLUSTERED INDEX idx_sales
ON Sales(custnum, partnum, repid)
GO

/* ------------ SNIPPET: Activity 5-1 Step 3c ------------ */
sp_help Sales
GO

/* ------------ SNIPPET: Activity 5-1 Step 4a ------------ */
CREATE UNIQUE CLUSTERED INDEX idx_partnum
ON Titles(partnum)
GO

/* ------------ SNIPPET: Activity 5-1 Step 4c ------------ */
sp_help Titles
GO

/* ------------ SNIPPET: Activity 5-2 Step 1a ------------ */
DROP INDEX Sales.idx_sales
GO

/* ------------ SNIPPET: Activity 5-2 Step 1c ------------ */
sp_help Sales
