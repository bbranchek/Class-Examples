-- Incorrect records
BEGIN TRAN Obs_Insert
INSERT INTO Obsolete_Titles VALUES 
('40255', 'How to Play Violin (Beginner)', 4580, 20, '2024-01-31'),
('40256', 'How to Play Violin (Intermediate)', 4580, 20, '2024-01-31'),
('40257', 'How to Play Violin (Advanced)', 4580, 20, '2024-01-31')
ROLLBACK TRAN Obs_Insert

-- Correct records
BEGIN TRAN Obs_Insert2
INSERT INTO Obsolete_Titles VALUES 
('40255', 'How to Play Mandolin (Beginner)', 4580, 25, '2024-01-31'),
('40256', 'How to Play Mandolin (Intermediate)', 4900, 30, '2024-01-31'),
('40257', 'How to Play Mandolin (Advanced)', 5300, 45, '2024-01-31')
COMMIT TRAN Obs_Insert2
