-- Step 5 query
SELECT *
FROM Obsolete_Titles
WHERE partnum IN ('40255', '40256', '40257')

-- Step 7 query
SELECT *
FROM Obsolete_Titles
WHERE partnum IN ('40255', '40256', '40257')
