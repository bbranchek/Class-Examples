/* -------------------------------------------------------
LESSON: Managing Transactions
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 6-1 Step 3a ------------ */
SELECT *
FROM Inventory

SELECT *
FROM Sales


/* ------------ SNIPPET: Activity 6-1 Step 4a ------------ */
SELECT *
FROM Inventory
WHERE partnum = '40897'

SELECT *
FROM Sales
WHERE partnum = '40897'


/* ------------ SNIPPET: Activity 6-1 Step 5a ------------ */
BEGIN TRAN Sales_Place_Order

	INSERT INTO Sales (ordnum, sldate, qty, custnum, partnum, repid)
	VALUES
	('00199', '2024-05-20', 10, '20151', '40897', 'N02') 

	UPDATE Inventory
	SET bookcount = bookcount - 10
	WHERE partnum = '40897'

	ROLLBACK TRAN
	-- Transaction failed


/* ------------ SNIPPET: Activity 6-2 Step 3b ------------ */
BEGIN TRAN Sales_Place_Order

	INSERT INTO Sales (ordnum, sldate, qty, custnum, partnum, repid)
	VALUES
	('00199', '2024-05-20', 5, '20151', '40897', 'N02') 

	UPDATE Inventory
	SET bookcount = bookcount - 5
	WHERE partnum = '40897'

	ROLLBACK TRAN
	-- Transaction failed

	COMMIT TRAN
	-- Transaction succeeded
