/* BE SURE TO HAVE RUN:  SELECT * INTO Titles_Revised
FROM TITLES in step 2 first

INSERT INTO Titles_Revised (partnum, bktitle, devcost, slprice, pubdate) 
VALUES 
('39906', 'Visual C++ Made Easy', NULL, 50, '2024-04-01'),
('39907', 'History of the Internet', NULL, 25, '2024-07-01'),
('39908', 'HTML5 Tips and Tricks', NULL, 35, '2024-08-01')
