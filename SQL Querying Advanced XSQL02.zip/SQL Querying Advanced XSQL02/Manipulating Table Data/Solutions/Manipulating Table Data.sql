-- Step 2 query
INSERT INTO Obsolete_Titles (partnum, bktitle, devcost, slprice, pubdate) 
VALUES ('39999', 'Learn to Play the Violin', 5000, 45, '2024-05-11')

SELECT * 
FROM Obsolete_Titles
WHERE partnum = '39999'


-- Step 3 query
UPDATE Obsolete_Titles
SET bktitle = 'Learn to Play the Mandolin'
WHERE partnum = '39999'

SELECT * 
FROM Obsolete_Titles
WHERE partnum = '39999'


-- Step 4 query
DELETE Obsolete_Titles 
WHERE partnum = '39999'

SELECT * 
FROM Obsolete_Titles
WHERE partnum = '39999'
