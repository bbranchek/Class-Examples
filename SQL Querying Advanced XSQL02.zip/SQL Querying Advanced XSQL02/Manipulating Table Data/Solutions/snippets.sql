/* -------------------------------------------------------
LESSON: Manipulating Table Data
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 2-1 Step 2a ------------ */
SELECT * INTO Titles_Revised
FROM Titles


/* ------------ SNIPPET: Activity 2-1 Step 4a ------------ */
SELECT *
FROM Titles_Revised


/* ------------ SNIPPET: Activity 2-1 Step 5a ------------ */
INSERT Titles_Revised
VALUES
('39909', 'SQL''s Role in Big Data', 19000, 30, '2024-09-01')


/* ------------ SNIPPET: Activity 2-1 Step 5d ------------ */
SELECT *
FROM Titles_Revised
WHERE partnum BETWEEN 39906 AND 39909


/* ------------ SNIPPET: Activity 2-2 Step 1a ------------ */
UPDATE Titles_Revised
SET devcost = 21000
WHERE partnum BETWEEN 39906 AND 39908


/* ------------ SNIPPET: Activity 2-2 Step 1c ------------ */
SELECT *
FROM Titles_Revised
WHERE partnum BETWEEN 39906 AND 39908


/* ------------ SNIPPET: Activity 2-2 Step 2b ------------ */
UPDATE Titles_Revised
SET bktitle = 'Java Programming Made Easy',
	devcost = 25000,
	slprice = 32.00,
	pubdate = '2024-11-01'
WHERE partnum = '39909'


/* ------------ SNIPPET: Activity 2-2 Step 2d ------------ */
SELECT *
FROM Titles_Revised
WHERE partnum = '39909'


/* ------------ SNIPPET: Activity 2-3 Step 1a ------------ */
DELETE Titles_Revised
WHERE partnum = '39907'


/* ------------ SNIPPET: Activity 2-3 Step 2a ------------ */
SELECT *
FROM Titles_Revised
WHERE partnum = '39907'


/* ------------ SNIPPET: Activity 2-4 Step 1a ------------ */
SELECT *
FROM Titles_Revised


/* ------------ SNIPPET: Activity 2-4 Step 1c ------------ */
TRUNCATE TABLE Titles_Revised

SELECT *
FROM Titles_Revised

