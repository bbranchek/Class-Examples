-- Step 2 query
CREATE TABLE Contractors (
    ctrid varchar (5) NOT NULL,
    fname varchar (10),
    lname varchar (10),
    salary money 
)

-- Step 3 query
sp_help Contractors

-- Step 4 query
ALTER TABLE Contractors ADD CONSTRAINT pkeycontr PRIMARY KEY (ctrid)

-- Step 5 query
sp_help Contractors

-- Step 6 query
ALTER TABLE Contractors ADD CHECK (salary > 0)

-- Step 7 query
sp_help Contractors

-- Step 8 query
DROP TABLE Contractors

-- Step 9 query
sp_help Contractors
