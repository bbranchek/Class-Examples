/* -------------------------------------------------------
LESSON: Manipulating the Table Structure
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 3-1 Step 2a ------------ */
CREATE TABLE Obsolete_Titles1 (
	partnum varchar(10) NOT NULL,
	bktitle varchar(80),
	devcost money,
	slprice money,
	pubdate smalldatetime
)


/* ------------ SNIPPET: Activity 3-1 Step 3b ------------ */
sp_help Obsolete_Titles1


/* ------------ SNIPPET: Activity 3-3 Step 1a ------------ */
CREATE TABLE Potential_Customers1 (
	custnum varchar(5) PRIMARY KEY,
	referredby varchar(5),
	custname varchar(30) NOT NULL,
	address varchar(50) NOT NULL,
	cellno varchar(15) CHECK (LEN(cellno) >= 10),
	repid varchar(3) NOT NULL
)


/* ------------ SNIPPET: Activity 3-3 Step 2a ------------ */
sp_help Potential_Customers1


/* ------------ SNIPPET: Activity 3-4 Step 1a ------------ */
ALTER TABLE Obsolete_Titles1 ADD pubaddress varchar(40)


/* ------------ SNIPPET: Activity 3-4 Step 2a ------------ */
ALTER TABLE Obsolete_Titles1 DROP COLUMN devcost


/* ------------ SNIPPET: Activity 3-4 Step 3a ------------ */
sp_help Obsolete_Titles1


/* ------------ SNIPPET: Activity 3-5 Step 1a ------------ */
SELECT * INTO Sales_Copy
FROM Sales


/* ------------ SNIPPET: Activity 3-5 Step 1a ------------ */
SELECT * INTO Sales_Copy
FROM Sales


/* ------------ SNIPPET: Activity 3-5 Step 2a ------------ */
sp_help Sales_Copy


/* ------------ SNIPPET: Activity 3-5 Step 3a ------------ */
ALTER TABLE Sales_Copy ADD CONSTRAINT pkeysales PRIMARY KEY (ordnum)


/* ------------ SNIPPET: Activity 3-5 Step 3c ------------ */
ALTER TABLE Sales_Copy ALTER COLUMN ordnum varchar(10) NOT NULL
ALTER TABLE Sales_Copy ADD CONSTRAINT pkeysales PRIMARY KEY (ordnum)


/* ------------ SNIPPET: Activity 3-5 Step 3f ------------ */
sp_help Sales_Copy


/* ------------ SNIPPET: Activity 3-6 Step 1a ------------ */
SELECT *
FROM Pub2.INFORMATION_SCHEMA.TABLES


/* ------------ SNIPPET: Activity 3-6 Step 2a ------------ */
DROP TABLE Obsolete_Titles1
DROP TABLE Potential_Customers1
DROP TABLE Sales_Copy

SELECT *
FROM Pub2.INFORMATION_SCHEMA.TABLES
