SELECT repid, fname, lname 
FROM Slspers
WHERE repid IN (
	SELECT repid
	FROM Sales
	GROUP BY repid
	HAVING SUM(qty) >= ALL (
		SELECT SUM(qty)
		FROM Sales
		GROUP BY repid))
