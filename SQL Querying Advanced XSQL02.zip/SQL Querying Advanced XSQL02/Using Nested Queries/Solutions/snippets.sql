/* -------------------------------------------------------
LESSON: Using Nested Queries
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 1-1 Step 3c ------------ */
SELECT *
FROM Slspers


/* ------------ SNIPPET: Activity 1-1 Step 4b ------------ */
SELECT repid, fname, lname, commrate
FROM Slspers
WHERE commrate > .03


/* ------------ SNIPPET: Activity 1-1 Step 5c ------------ */
SELECT repid, fname, lname, commrate
FROM Slspers
WHERE commrate > 
	(SELECT AVG(commrate) FROM Slspers)


/* ------------ SNIPPET: Activity 1-2 Step 1a ------------ */
SELECT partnum, bktitle
FROM Titles


/* ------------ SNIPPET: Activity 1-2 Step 1c ------------ */
SELECT partnum, bktitle
FROM Titles
WHERE partnum NOT IN
	(SELECT partnum FROM Sales)


/* ------------ SNIPPET: Activity 1-3 Step 1a ------------ */
SELECT *
FROM Obsolete_Titles
ORDER BY devcost

SELECT *
FROM Titles
ORDER BY devcost


/* ------------ SNIPPET: Activity 1-3 Step 2a ------------ */
SELECT *
FROM Obsolete_Titles
ORDER BY devcost

SELECT *
FROM Titles
WHERE devcost < ALL (SELECT devcost FROM Obsolete_Titles)
ORDER BY devcost

SELECT *
FROM Titles
WHERE devcost < ANY (SELECT devcost FROM Obsolete_Titles)
ORDER BY devcost

SELECT *
FROM Titles
WHERE devcost < SOME (SELECT devcost FROM Obsolete_Titles)
ORDER BY devcost




/* ------------ SNIPPET: Activity 1-4 Step 1a ------------ */
SELECT partnum FROM Obsolete_Titles
SELECT partnum FROM Obsolete_Titles WHERE partnum = 39213
SELECT partnum FROM Obsolete_Titles WHERE partnum = 99999


/* ------------ SNIPPET: Activity 1-4 Step 2d ------------ */
SELECT *
FROM Titles
WHERE EXISTS
	(SELECT partnum FROM Obsolete_Titles WHERE partnum = Titles.partnum)


/* ------------ SNIPPET: Activity 1-4 Step 3a ------------ */
SELECT *
FROM Titles
WHERE EXISTS
	(SELECT partnum FROM Obsolete_Titles WHERE partnum = Titles.partnum)

SELECT * FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 1-4 Step 4b ------------ */
SELECT *
FROM Titles
WHERE EXISTS
	(SELECT partnum FROM Obsolete_Titles WHERE partnum = Titles.partnum
	AND bktitle = Titles.bktitle)

SELECT * FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 1-4 Step 5a ------------ */
SELECT *
FROM Titles
WHERE NOT EXISTS
	(SELECT partnum FROM Obsolete_Titles WHERE partnum = Titles.partnum
	AND bktitle = Titles.bktitle)

SELECT * FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 1-5 Step 1a ------------ */
SELECT *
FROM Titles
CROSS JOIN Customers


/* ------------ SNIPPET: Activity 1-5 Step 2a ------------ */
SELECT partnum, bktitle, custnum, custname, address
FROM Titles
CROSS JOIN Customers


/* ------------ SNIPPET: Activity 1-5 Step 3a ------------ */
SELECT partnum, bktitle, custnum, custname, address
FROM Titles
CROSS JOIN Customers

SELECT * FROM Sales


/* ------------ SNIPPET: Activity 1-5 Step 3d ------------ */
SELECT partnum, bktitle, custnum, custname, address
FROM Titles
CROSS JOIN Customers

SELECT * FROM Sales
WHERE Sales.custnum = 20181
AND Sales.partnum = 40321


/* ------------ SNIPPET: Activity 1-5 Step 4e ------------ */
SELECT partnum, bktitle, custnum, custname, address
FROM Titles
CROSS JOIN Customers
WHERE 500 IN
    (SELECT qty FROM Sales
    WHERE Sales.custnum = Customers.custnum
    AND Sales.partnum = Titles.partnum)


/* ------------ SNIPPET: Activity 1-6 Step 1a ------------ */
SELECT *
FROM Slspers
OUTER APPLY Sales
WHERE Slspers.repid = Sales.repid


/* ------------ SNIPPET: Activity 1-7 Step 1a ------------ */
SELECT *
FROM Slspers


/* ------------ SNIPPET: Activity 1-7 Step 2a ------------ */
SELECT *
FROM Slspers

SELECT repid FROM Sales
GROUP BY repid
HAVING SUM(qty) >= 2375


/* ------------ SNIPPET: Activity 1-7 Step 3b ------------ */
SELECT *
FROM Slspers
WHERE repid IN
	(SELECT repid FROM Sales
	GROUP BY repid
	HAVING SUM(qty) >= 2375)


/* ------------ SNIPPET: Activity 1-8 Step 1a ------------ */
SELECT *
FROM Customers

SELECT *
FROM Sales

SELECT *
FROM Titles
WHERE slprice > 49


/* ------------ SNIPPET: Activity 1-8 Step 3c ------------ */
SELECT custnum, custname, address, city
FROM Customers
WHERE custnum IN (
	SELECT custnum
	FROM Sales
	WHERE partnum IN (
		SELECT partnum
		FROM Titles
		WHERE slprice > 49))
