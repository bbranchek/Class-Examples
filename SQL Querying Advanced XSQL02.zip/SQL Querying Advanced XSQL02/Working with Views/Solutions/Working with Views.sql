-- Step 2 query
CREATE VIEW Cust_View 
AS 
SELECT custnum, custname, address 
FROM Customers

-- Step 3 query
SELECT * 
FROM Cust_View

-- Step 4 query
ALTER VIEW Cust_View
AS 
SELECT address, city, state, zipcode 
FROM Customers

-- Step 5 query
SELECT * 
FROM Cust_View

-- Step 6 query
DROP VIEW Cust_View

-- Step 7 query
SELECT * 
FROM Cust_View