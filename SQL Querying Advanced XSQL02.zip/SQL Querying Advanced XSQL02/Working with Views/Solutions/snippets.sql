/* -------------------------------------------------------
LESSON: Working with Views
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 4-1 Step 2a ------------ */
SELECT partnum, bktitle, slprice
FROM Titles
WHERE slprice BETWEEN 20 AND 40


/* ------------ SNIPPET: Activity 4-1 Step 3a ------------ */
CREATE VIEW Medium_Price
AS
SELECT partnum, bktitle, slprice
FROM Titles
WHERE slprice BETWEEN 20 AND 40


/* ------------ SNIPPET: Activity 4-1 Step 3c ------------ */
SELECT *
FROM Medium_Price


/* ------------ SNIPPET: Activity 4-1 Step 3e ------------ */
sp_helptext Medium_Price


/* ------------ SNIPPET: Activity 4-1 Step 4a ------------ */
CREATE VIEW Sales_Perf
AS
SELECT TOP 20 Sales.partnum, Titles.bktitle, SUM(Sales.qty) AS 'Total Qty'
FROM Sales INNER JOIN Titles ON Sales.partnum = Titles.partnum
GROUP BY Sales.partnum, Titles.bktitle
ORDER BY SUM(Sales.qty) DESC


/* ------------ SNIPPET: Activity 4-1 Step 5c ------------ */
SELECT *
FROM Sales_Perf


/* ------------ SNIPPET: Activity 4-2 Step 1a ------------ */
CREATE VIEW Customer_View
WITH SCHEMABINDING
AS
SELECT custname
FROM dbo.Customers


/* ------------ SNIPPET: Activity 4-2 Step 2a ------------ */
-- deliberate error schema bound
ALTER TABLE Customers
ALTER COLUMN custname varchar(30) NOT NULL


/* ------------ SNIPPET: Activity 4-3 Step 1a ------------ */
INSERT Medium_Price (partnum, bktitle, slprice)
VALUES ('40256', 'How to Play Violin (Intermediate)', 35)

INSERT Medium_Price (partnum, bktitle, slprice)
VALUES ('40257', 'How to Play Violin (Advanced)', 39)


/* ------------ SNIPPET: Activity 4-3 Step 1c ------------ */
SELECT *
FROM Medium_Price
WHERE partnum IN ('40256', '40257')


/* ------------ SNIPPET: Activity 4-3 Step 2a ------------ */
UPDATE Medium_Price
SET slprice = 30
WHERE partnum = '40256'


/* ------------ SNIPPET: Activity 4-3 Step 2c ------------ */
SELECT *
FROM Medium_Price
WHERE partnum = '40256'


/* ------------ SNIPPET: Activity 4-3 Step 3a ------------ */
DELETE Medium_Price
WHERE partnum = '40234'


/* ------------ SNIPPET: Activity 4-3 Step 3c ------------ */
SELECT *
FROM Medium_Price
WHERE partnum = '40234'


/* ------------ SNIPPET: Activity 4-4 Step 1a ------------ */
sp_helptext Sales_Perf


/* ------------ SNIPPET: Activity 4-4 Step 2a ------------ */
ALTER VIEW Sales_Perf  
AS  
SELECT TOP 3 Sales.partnum, Titles.bktitle, SUM(Sales.qty) AS 'Total Qty'  
FROM Sales INNER JOIN Titles ON Sales.partnum = Titles.partnum  
GROUP BY Sales.partnum, Titles.bktitle  
ORDER BY SUM(Sales.qty) DESC


/* ------------ SNIPPET: Activity 4-4 Step 3a ------------ */
SELECT *
FROM Sales_Perf


/* ------------ SNIPPET: Activity 4-4 Step 4a ------------ */
DROP VIEW Medium_Price


/* ------------ SNIPPET: Activity 4-4 Step 4c ------------ */
SELECT *
FROM Medium_Price
