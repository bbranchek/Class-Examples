-- Step 3 queries
SELECT * FROM Customers

SELECT * FROM Titles

SELECT * FROM Slspers

SELECT * FROM Sales

-- Step 4 query
SELECT custname, address, city, state, zipcode 
FROM Customers

-- Step 5 query
SELECT bktitle, partnum, slprice
FROM Titles

-- Step 6 query
SELECT repid, fname, lname 
FROM Slspers

-- Step 7 query
SELECT ordnum, partnum, qty 
FROM Sales
