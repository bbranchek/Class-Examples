/* -------------------------------------------------------
LESSON: Executing a Simple Query
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 1-1 Step 3b ------------ */
USE Pub1


/* ------------ SNIPPET: Activity 1-2 Step 2a ------------ */
USE Pub1
SELECT *
FROM Titles


/* ------------ SNIPPET: Activity 1-2 Step 4f ------------ */
USE Pub1
SELECT Titles.bktitle, Titles.slprice
FROM Titles


/* ------------ SNIPPET: Activity 1-4 Step 1D ------------ */
sp_help Titles


/* ------------ SNIPPET: Activity 1-4 Step 5b ------------ */
USE Pub1
SELECT Titles.partnum, Titles.bktitle, Titles.slprice
FROM Titles


/* ------------ SNIPPET: Activity 1-4 Step 6b ------------ */
USE Pub1

-- List of current book prices
SELECT Titles.partnum, Titles.bktitle, Titles.slprice
FROM Titles
