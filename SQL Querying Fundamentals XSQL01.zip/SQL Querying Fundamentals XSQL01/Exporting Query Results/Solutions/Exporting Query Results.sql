-- Step 2 query
SELECT bktitle, devcost, slprice
FROM Titles 
WHERE devcost IS NOT NULL
ORDER BY bktitle ASC

-- Step 4 query
SELECT bktitle, devcost, slprice
FROM Titles 
WHERE devcost IS NOT NULL
ORDER BY bktitle ASC
FOR XML AUTO, TYPE, ELEMENTS
