-- Step 2 query
SELECT partnum, SUM(qty) quantity
FROM Sales
WHERE qty IS NOT NULL
GROUP BY partnum
ORDER BY SUM(qty) DESC

-- Step 3 query
SELECT repid, SUM(qty) quantity
FROM Sales
WHERE qty IS NOT NULL
GROUP BY repid
HAVING SUM(qty) >= 2000
ORDER BY SUM(qty)
