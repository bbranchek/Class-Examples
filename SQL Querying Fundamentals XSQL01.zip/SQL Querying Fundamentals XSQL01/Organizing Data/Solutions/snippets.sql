/* -------------------------------------------------------
LESSON: Organizing Data
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 4-1 Step 2a ------------ */
SELECT bktitle, slprice
FROM Titles
ORDER BY slprice DESC, bktitle


/* ------------ SNIPPET: Activity 4-1 Step 3a ------------ */
SELECT bktitle, slprice, devcost, devcost / slprice AS breakeven_point
FROM Titles
WHERE devcost IS NOT NULL
ORDER BY devcost / slprice


/* ------------ SNIPPET: Activity 4-2 Step 1a ------------ */
SELECT repid, qty, custnum
FROM Sales
WHERE DATEPART(year, sldate) = 2024


/* ------------ SNIPPET: Activity 4-2 Step 2a ------------ */
SELECT repid, qty, custnum
	, RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Rank'
FROM Sales
WHERE DATEPART(year, sldate) = 2024


/* ------------ SNIPPET: Activity 4-2 Step 3a ------------ */
SELECT repid, qty, custnum
	, RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Rank'
	, DENSE_RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Dense Rank'
FROM Sales
WHERE DATEPART(year, sldate) = 2024


/* ------------ SNIPPET: Activity 4-2 Step 4a ------------ */
SELECT repid, qty, custnum
	, RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Rank'
	, DENSE_RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Dense Rank'
	, NTILE(5) OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Ntile'
	, ROW_NUMBER() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Row Number'
FROM Sales
WHERE DATEPART(year, sldate) = 2024


/* ------------ SNIPPET: Activity 4-3 Step 1b ------------ */
SELECT repid, qty, custnum
FROM Sales
WHERE DATEPART(year, sldate) = 2024
ORDER BY repid


/* ------------ SNIPPET: Activity 4-3 Step 2a ------------ */
SELECT repid, qty, custnum
FROM Sales
WHERE DATEPART(year, sldate) = 2024
GROUP BY repid


/* ------------ SNIPPET: Activity 4-3 Step 3a ------------ */
SELECT repid, COUNT(DISTINCT custnum) AS #_Cust
FROM Sales
WHERE DATEPART(year, sldate) = 2024
GROUP BY repid


/* ------------ SNIPPET: Activity 4-4 Step 1a ------------ */
SELECT repid, COUNT(DISTINCT custnum) AS #_Cust
FROM Sales
WHERE DATEPART(year, sldate) = 2024
GROUP BY repid
HAVING SUM(qty) >= 2000


/* ------------ SNIPPET: Activity 4-5 Step 1a ------------ */
SELECT repid, custnum, SUM(qty) AS annual_total
FROM Sales
WHERE DATEPART(year, sldate) = 2024
GROUP BY repid, custnum


/* ------------ SNIPPET: Activity 4-5 Step 2a ------------ */
SELECT repid, custnum, SUM(qty) AS annual_total
FROM Sales
WHERE DATEPART(year, sldate) = 2024
GROUP BY repid, custnum WITH ROLLUP


/* ------------ SNIPPET: Activity 4-6 Step 1a ------------ */
SELECT LEFT(DATENAME(month, sldate), 3) AS mo, qty, repid
FROM Sales


/* ------------ SNIPPET: Activity 4-6 Step 2b ------------ */
SELECT * FROM (
	SELECT LEFT(DATENAME(month, sldate), 3) AS mo, qty, repid
	FROM Sales
) AS source


/* ------------ SNIPPET: Activity 4-6 Step 3a ------------ */
SELECT * FROM (
	SELECT LEFT(DATENAME(month, sldate), 3) AS mo, qty, repid
	FROM Sales
) AS source
PIVOT (SUM(qty) FOR mo IN (Jan, Feb, Mar, Apr, May, Jun)) AS pivoted
