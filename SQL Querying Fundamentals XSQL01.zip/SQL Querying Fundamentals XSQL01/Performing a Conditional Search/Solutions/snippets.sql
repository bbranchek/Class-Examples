/* -------------------------------------------------------
LESSON: Performing a Conditional Search
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 2-1 Step 2d ------------ */
SELECT partnum, bktitle, slprice
FROM Titles
WHERE slprice >= 50


/* ------------ SNIPPET: Activity 2-1 Step 3a ------------ */
SELECT partnum, bktitle, slprice
FROM Titles
WHERE bktitle = 'Sailing'


/* ------------ SNIPPET: Activity 2-2 Step 1a ------------ */
SELECT partnum, bktitle, slprice
FROM Titles


/* ------------ SNIPPET: Activity 2-2 Step 2a ------------ */
SELECT partnum, bktitle, slprice - slprice * 0.07
FROM Titles


/* ------------ SNIPPET: Activity 2-2 Step 3a ------------ */
SELECT partnum, bktitle, slprice - slprice * 0.07 AS discounted_price
FROM Titles


/* ------------ SNIPPET: Activity 2-2 Step 4a ------------ */
SELECT partnum, bktitle, slprice - slprice * 0.07 AS discounted_price
FROM Titles
WHERE slprice - slprice * 0.07 >= 45


/* ------------ SNIPPET: Activity 2-3 Step 1b ------------ */
SELECT city, state, custname
FROM Customers
WHERE state = 'NY'


/* ------------ SNIPPET: Activity 2-3 Step 2a ------------ */
SELECT city, state, custname
FROM Customers
WHERE state = 'NY' OR state = 'MA'


/* ------------ SNIPPET: Activity 2-3 Step 3a ------------ */
SELECT city, state, custname, repid
FROM Customers
WHERE state = 'NY' OR state = 'MA' AND repid = 'S01'


/* ------------ SNIPPET: Activity 2-3 Step 4a ------------ */
SELECT city, state, custname, repid
FROM Customers
WHERE (state = 'NY' OR state = 'MA') AND repid = 'S01'


/* ------------ SNIPPET: Activity 2-4 Step 1a ------------ */
SELECT bktitle, slprice
FROM Titles
WHERE slprice BETWEEN 35 AND 70


/* ------------ SNIPPET: Activity 2-4 Step 2a ------------ */
SELECT bktitle, slprice, devcost
FROM Titles
WHERE devcost IS NULL


/* ------------ SNIPPET: Activity 2-4 Step 3a ------------ */
SELECT bktitle, slprice, devcost
FROM Titles
WHERE devcost IS NOT NULL


/* ------------ SNIPPET: Activity 2-5 Step 1a ------------ */
SELECT bktitle, partnum, slprice
FROM Titles
WHERE bktitle LIKE '%art%'


/* ------------ SNIPPET: Activity 2-5 Step 2a ------------ */
SELECT bktitle, partnum, slprice
FROM Titles
WHERE bktitle LIKE '[AMC]%'


/* ------------ SNIPPET: Activity 2-5 Step 3a ------------ */
SELECT bktitle, partnum, slprice
FROM Titles
WHERE bktitle LIKE '[A-G]%'


/* ------------ SNIPPET: Activity 2-5 Step 4a ------------ */
SELECT custnum, custname, city
FROM Customers
WHERE custnum LIKE '____'


/* ------------ SNIPPET: Activity 2-5 Step 5a ------------ */
SELECT custnum, custname, city
FROM Customers
WHERE custnum LIKE '___[19]'
