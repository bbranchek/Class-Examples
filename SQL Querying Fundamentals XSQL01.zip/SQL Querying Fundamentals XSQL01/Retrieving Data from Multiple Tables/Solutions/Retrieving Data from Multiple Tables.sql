-- Step 2 query
SELECT custname, RTRIM(address) + ', ' + RTRIM(city) + ', ' + 
state + ' - ' + zipcode address
FROM Customers
UNION
SELECT custname, RTRIM(address) + ', ' + RTRIM(city) + ', ' + 
state + ' - ' + zipcode
FROM Potential_Customers

-- Step 3 query
SELECT ordnum, custname, bktitle, 
RTRIM(p.fname) + ' ' + RTRIM(p.lname) rep_name, qty
FROM Sales s INNER JOIN Customers c ON s.custnum = c.custnum
INNER JOIN Slspers p ON s.repid = p.repid 
INNER JOIN Titles t ON t.partnum = s.partnum
