/* -------------------------------------------------------
LESSON: Retrieving Data from Multiple Tables
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 5-1 Step 2a ------------ */
SELECT partnum, bktitle, pubdate
FROM Titles


/* ------------ SNIPPET: Activity 5-1 Step 3b ------------ */
SELECT partnum, bktitle, pubdate
FROM Titles

SELECT partnum, bktitle, pubdate
FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 5-1 Step 4a ------------ */
SELECT partnum, bktitle, pubdate
FROM Titles
UNION
SELECT partnum, bktitle, pubdate
FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 5-1 Step 5a ------------ */
SELECT partnum, bktitle
FROM Titles
UNION
SELECT partnum, bktitle
FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 5-1 Step 6a ------------ */
SELECT partnum, bktitle
FROM Titles
UNION ALL
SELECT partnum, bktitle
FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 5-2 Step 1a ------------ */
SELECT partnum, bktitle
FROM Titles
INTERSECT
SELECT partnum, bktitle
FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 5-2 Step 2a ------------ */
SELECT partnum, bktitle
FROM Titles
EXCEPT
SELECT partnum, bktitle
FROM Obsolete_Titles


/* ------------ SNIPPET: Activity 5-3 Step 1a ------------ */
SELECT ordnum, sldate, qty, repid
FROM Sales

SELECT repid, fname, lname
FROM Slspers


/* ------------ SNIPPET: Activity 5-3 Step 2d ------------ */
SELECT ordnum, sldate, qty, Sales.repid, fname, lname
FROM Sales
INNER JOIN Slspers ON Sales.repid = Slspers.repid
ORDER BY qty DESC


/* ------------ SNIPPET: Activity 5-4 Step 1a ------------ */
SELECT *
FROM Titles

SELECT *
FROM Sales


/* ------------ SNIPPET: Activity 5-4 Step 2a ------------ */
SELECT partnum
FROM Titles
EXCEPT
SELECT partnum
FROM Sales


/* ------------ SNIPPET: Activity 5-4 Step 3a ------------ */
SELECT bktitle, qty
FROM Titles LEFT OUTER JOIN Sales
ON Titles.partnum = Sales.partnum


/* ------------ SNIPPET: Activity 5-4 Step 4a ------------ */
SELECT bktitle, SUM(qty) AS total_qty
FROM Titles LEFT OUTER JOIN Sales
ON Titles.partnum = Sales.partnum
GROUP BY bktitle


/* ------------ SNIPPET: Activity 5-5 Step 1a ------------ */
SELECT *
FROM Potential_Customers


/* ------------ SNIPPET: Activity 5-5 Step 2b ------------ */
SELECT *
FROM Potential_Customers AS custlist
INNER JOIN Potential_Customers AS referredlist
ON custlist.referredby = referredlist.custnum


/* ------------ SNIPPET: Activity 5-5 Step 3a ------------ */
SELECT custlist.custname, referredlist.custname AS referred_by
FROM Potential_Customers AS custlist
INNER JOIN Potential_Customers AS referredlist
ON custlist.referredby = referredlist.custnum
