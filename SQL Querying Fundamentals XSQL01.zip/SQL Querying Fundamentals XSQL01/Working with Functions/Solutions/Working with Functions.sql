-- Step 2 query
SELECT * 
FROM Sales 
WHERE DATEPART(year, sldate) = 2024
AND DATEPART(month, sldate) BETWEEN 1 AND 6 

-- Step 3 query
SELECT * 
FROM Sales 
WHERE qty >= 400 AND DATEPART(year, sldate) = 2024
AND DATEPART(month, sldate) BETWEEN 1 AND 6 

-- Step 4 query
SELECT SUM(qty) sum_qty, COUNT(qty) count_qty 
FROM Sales 
WHERE qty >= 400 AND DATEPART(year, sldate) = 2024 
AND DATEPART(month, sldate) BETWEEN 1 AND 6 

-- Step 5 query
SELECT * 
FROM Customers 
WHERE LEN(custnum) = 4
