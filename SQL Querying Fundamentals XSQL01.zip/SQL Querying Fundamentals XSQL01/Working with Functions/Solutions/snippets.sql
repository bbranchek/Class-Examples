/* -------------------------------------------------------
LESSON: Working with Functions
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 3-1 Step 2a ------------ */
sp_help Obsolete_Titles


/* ------------ SNIPPET: Activity 3-1 Step 4a ------------ */
SELECT bktitle
	, pubdate
	, DATEPART(year, pubdate) AS year
	, DATEDIFF(year, pubdate, GETDATE()) AS age
FROM Obsolete_Titles
WHERE pubdate BETWEEN '1/1/1999' AND '12/31/2010'


/* ------------ SNIPPET: Activity 3-1 Step 5b ------------ */
SELECT bktitle
	, pubdate
	, DATEPART(year, pubdate) AS year
	, DATEDIFF(year, pubdate, GETDATE()) AS age
FROM Obsolete_Titles
-- WHERE pubdate BETWEEN '1/1/1999' AND '12/31/2010'
WHERE DATEPART(year, pubdate) BETWEEN 1999 AND 2010


/* ------------ SNIPPET: Activity 3-2 Step 1a ------------ */
SELECT *
FROM Titles
WHERE DATEPART(year, pubdate) = 2024


/* ------------ SNIPPET: Activity 3-2 Step 2a ------------ */
SELECT COUNT(bktitle) AS title_count
	, SUM(devcost) AS devcost_total
	, AVG(devcost) AS devcost_average
FROM Titles
WHERE DATEPART(year, pubdate) = 2024


/* ------------ SNIPPET: Activity 3-2 Step 3a ------------ */
SELECT COUNT(*) AS #_rows
	, COUNT(bktitle) AS title_count
	, COUNT(slprice) AS price_count
	, COUNT(DISTINCT slprice) AS distinct_price_count
	, COUNT(devcost) AS devcost_count
	, SUM(devcost) AS devcost_total
	, AVG(devcost) AS devcost_average
FROM Titles
WHERE DATEPART(year, pubdate) = 2024


/* ------------ SNIPPET: Activity 3-3 Step 1b ------------ */
SELECT custname
	, address AS street
	, city + ', ' + state + ' ' + zipcode AS citystatezip
FROM Customers


/* ------------ SNIPPET: Activity 3-3 Step 2B ------------ */
SELECT custname
	, address AS street
	, TRIM(city) + ', ' + state + ' ' + zipcode AS citystatezip
FROM Customers
