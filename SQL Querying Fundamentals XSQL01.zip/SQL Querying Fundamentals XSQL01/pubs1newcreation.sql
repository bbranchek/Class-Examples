USE [Pub1]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 2/20/2025 11:03:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customers](
	[custnum] [nvarchar](5) NULL,
	[referredby] [nvarchar](5) NULL,
	[custname] [nvarchar](30) NULL,
	[address] [nvarchar](25) NULL,
	[city] [nvarchar](20) NULL,
	[state] [nvarchar](2) NULL,
	[zipcode] [nvarchar](12) NULL,
	[repid] [nvarchar](3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Obsolete_Titles]    Script Date: 2/20/2025 11:03:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Obsolete_Titles](
	[partnum] [nvarchar](5) NULL,
	[bktitle] [nvarchar](40) NULL,
	[devcost] [money] NULL,
	[slprice] [money] NULL,
	[pubdate] [smalldatetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Potential_Customers]    Script Date: 2/20/2025 11:03:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Potential_Customers](
	[custnum] [nvarchar](5) NULL,
	[referredby] [nvarchar](5) NULL,
	[custname] [nvarchar](30) NULL,
	[address] [nvarchar](25) NULL,
	[city] [nvarchar](20) NULL,
	[state] [nvarchar](2) NULL,
	[zipcode] [nvarchar](12) NULL,
	[repid] [nvarchar](3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Sales]    Script Date: 2/20/2025 11:03:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Sales](
	[ordnum] [nvarchar](5) NULL,
	[sldate] [smalldatetime] NULL,
	[qty] [int] NULL,
	[custnum] [nvarchar](5) NULL,
	[partnum] [nvarchar](5) NULL,
	[repid] [nvarchar](3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Slspers]    Script Date: 2/20/2025 11:03:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Slspers](
	[repid] [nvarchar](3) NULL,
	[fname] [nvarchar](10) NULL,
	[lname] [nvarchar](20) NULL,
	[commrate] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Titles]    Script Date: 2/20/2025 11:03:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Titles](
	[partnum] [nvarchar](5) NULL,
	[bktitle] [nvarchar](40) NULL,
	[devcost] [money] NULL,
	[slprice] [money] NULL,
	[pubdate] [smalldatetime] NULL
) ON [PRIMARY]
GO
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20042', N'20555', N'CK Music!', N'#1149 Blossom Road       ', N'Rochester           ', N'NY', N'14610       ', N'S01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20151', N'20330', N'Friendly Books', N'19 International Dr.     ', N'Ryebrook            ', N'NY', N'10573       ', N'S03')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20181', N'20506', N'The Book Stop', N'512 Columbia Road        ', N'Somerville          ', N'NJ', N'08876', N'E02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20309', N'20151', N'Mary''s Card Shoppe', N'981 Connecticut Blvd.    ', N'East Hartford       ', N'CT', N'06108       ', N'S01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20330', N'99999', N'TechTraining', N'51 Ulster St.            ', N'Denver              ', N'CO', N'80237       ', N'S03')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20417', N'20506', N'Harvey & Sons Publishing', N'99 West 77th St.         ', N'Edina               ', N'MN', N'55435       ', N'W01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20437', N'99999', N'Cards for All Occasions       ', N'99 South Downing         ', N'Westchester         ', N'IL', N'60154       ', N'W02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20482', N'20181', N'Kolleen''s Kraft Supplies', N'2 Kirts Boulevard        ', N'Troy                ', N'MI', N'48084       ', N'S02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20493', N'20573', N'Murphy''s Drug Store', N'7110 Cordero Drive       ', N'San Francisco       ', N'CA', N'96910       ', N'N01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20503', N'9989', N'Smithson Tech Ltd.', N'396 Apache River Ave.    ', N'Fountain Valley     ', N'CA', N'92708       ', N'N01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20506', N'9989', N'Frank''s Music Shop', N'51 Windsor Street        ', N'Cambridge           ', N'MA', N'02139       ', N'S01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20512', N'20437', N'TLC Gardening Galore', N'79 Gessner               ', N'Houston             ', N'TX', N'77024       ', N'S03')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20527', N'99999', N'Pet Shoppe', N'40 Knox Park Road        ', N'Lake Zurich         ', N'IL', N'60047       ', N'W02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20555', N'8864', N'Brainy Learning Center', N'615 Richmond Ave.        ', N'Houston             ', N'TX', N'77042       ', N'S02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20557', N'99999', N'Prince''s Pets', N'74 Oak St.               ', N'Buffalo             ', N'NY', N'14053       ', N'S01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'20573', N'21516', N'Smithson Travel', N'5619 114th Ave. N.W.     ', N'Bellevue            ', N'WA', N'98004       ', N'E03')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'21133', N'99999', N'Toujours Tours', N'27 International Dr.     ', N'Ryebrook            ', N'NY', N'10573       ', N'S01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'21151', N'99999', N'Scholarly School', N'12 Harbor Blvd.          ', N'Santa Ana           ', N'CA', N'92704       ', N'S03')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'21160', N'20573', N'One Stop Bookshop', N'22 International Dr.     ', N'Ryebrook            ', N'NY', N'10573       ', N'W02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'21516', N'20330', N'Favorite Florist', N'81 114th Ave.            ', N'Bellevue            ', N'WA', N'98004       ', N'S01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'8802', N'9989', N'Pretty Gardens', N'289 Jacoban St.          ', N'Quebec              ', N'CA', N'H8R 1C3     ', N'N02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'8864', N'99999', N'Marty''s Books', N'49 West Nash Street      ', N'Wilson              ', N'NC', N'27893       ', N'N02')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'9517', N'20506', N'The Corner Bookstore          ', N'36 North Miller Avenue   ', N'Syracuse            ', N'NY', N'13206       ', N'E01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'9881', N'21516', N'Advertising & Graphic Design', N'2008 Delta Ave.          ', N'Cincinnati          ', N'OH', N'45208       ', N'E01')
INSERT [dbo].[Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'9989', N'20573', N'National Learners', N'39 Gallimore Dairy Road  ', N'Greensboro          ', N'NC', N'27409       ', N'N02')
GO
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39213', N'When Birds Do not Fly                   ', 42562.7500, 29.9500, CAST(N'2008-04-07T00:00:00' AS SmallDateTime))
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39422', N'Hammer and Nails                        ', 35024.0000, 42.5000, CAST(N'2004-09-10T00:00:00' AS SmallDateTime))
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39778', N'Taking a Walk Alone                     ', 12981.5500, 35.9500, CAST(N'2006-03-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39779', N'Learning to Diet                        ', 9000.0000, 21.9500, CAST(N'2004-09-15T00:00:00' AS SmallDateTime))
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39782', N'Wonderful Thoughts and Marvellous Dreams', 11233.7500, 25.5000, CAST(N'2001-02-10T00:00:00' AS SmallDateTime))
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39843', N'Clear Cupboards                         ', 15055.5000, 49.9500, CAST(N'2006-08-19T00:00:00' AS SmallDateTime))
INSERT [dbo].[Obsolete_Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39905', N'Y2K Why Worry?', 19990.0000, 45.0000, CAST(N'2007-01-01T00:00:00' AS SmallDateTime))
GO
INSERT [dbo].[Potential_Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'31001', N'31004', N'Empire Books', N'911 Empire Blvd.         ', N'Cincinnati          ', N'OH', N'45208       ', N'E01')
INSERT [dbo].[Potential_Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'31002', N'31005', N'Book Publishers, Inc.', N'3 Park Ave.              ', N'Wilson              ', N'NC', N'27893       ', N'N02')
INSERT [dbo].[Potential_Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'31003', N'31002', N'BxB Fitness', N'15 Main St.              ', N'Syracuse            ', N'NY', N'13206       ', N'E01')
INSERT [dbo].[Potential_Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'31004', N'31002', N'The Family Sing Center', N'224 Phillips Ave.        ', N'Santa Ana           ', N'CA', N'92704       ', N'S03')
INSERT [dbo].[Potential_Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'31005', N'31004', N'Hand Loved Craft Supplies', N'57 Underwood Blvd.       ', N'Troy                ', N'MI', N'48084       ', N'S02')
INSERT [dbo].[Potential_Customers] ([custnum], [referredby], [custname], [address], [city], [state], [zipcode], [repid]) VALUES (N'9517', N'', N'Leaps & Bounds Travel', N'36 North Miller Ave.     ', N'Syracuse            ', N'NY', N'13206       ', N'E01')
GO
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00101', CAST(N'2024-11-16T00:00:00' AS SmallDateTime), 220, N'20503', N'40125', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00102', CAST(N'2024-11-20T00:00:00' AS SmallDateTime), 100, N'8802', N'40232', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00103', CAST(N'2024-11-20T00:00:00' AS SmallDateTime), 170, N'9989', N'40641', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00104', CAST(N'2024-12-07T00:00:00' AS SmallDateTime), 100, N'9989', N'40562', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00105', CAST(N'2024-12-14T00:00:00' AS SmallDateTime), 150, N'20493', N'40481', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00106', CAST(N'2024-12-16T00:00:00' AS SmallDateTime), 200, N'9989', N'40712', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00107', CAST(N'2024-12-22T00:00:00' AS SmallDateTime), 200, N'9989', N'40562', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00108', CAST(N'2024-01-11T00:00:00' AS SmallDateTime), 200, N'20417', N'40125', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00109', CAST(N'2024-01-12T00:00:00' AS SmallDateTime), 250, N'8802', N'40231', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00110', CAST(N'2024-01-12T00:00:00' AS SmallDateTime), 250, N'20330', N'40482', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00111', CAST(N'2024-01-18T00:00:00' AS SmallDateTime), 100, N'9989', N'40551', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00112', CAST(N'2024-01-20T00:00:00' AS SmallDateTime), 120, N'8802', N'40251', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00113', CAST(N'2024-01-20T00:00:00' AS SmallDateTime), 400, N'20417', N'40614', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00114', CAST(N'2024-01-20T00:00:00' AS SmallDateTime), 100, N'20506', N'40253', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00115', CAST(N'2024-01-22T00:00:00' AS SmallDateTime), 190, N'8802', N'40233', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00116', CAST(N'2024-01-26T00:00:00' AS SmallDateTime), 100, N'8802', N'40231', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00117', CAST(N'2024-01-27T00:00:00' AS SmallDateTime), 200, N'20493', N'40564', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00118', CAST(N'2024-01-29T00:00:00' AS SmallDateTime), 240, N'20503', N'40526', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00119', CAST(N'2024-02-02T00:00:00' AS SmallDateTime), 200, N'21133', N'40581', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00120', CAST(N'2019-02-05T00:00:00' AS SmallDateTime), 180, N'20503', N'40231', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00121', CAST(N'2024-02-09T00:00:00' AS SmallDateTime), 100, N'20506', N'40251', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00122', CAST(N'2024-02-09T00:00:00' AS SmallDateTime), 100, N'21133', N'40521', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00123', CAST(N'2024-02-12T00:00:00' AS SmallDateTime), 150, N'8864', N'40562', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00124', CAST(N'2024-02-15T00:00:00' AS SmallDateTime), 180, N'9881', N'40564', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00125', CAST(N'2024-02-15T00:00:00' AS SmallDateTime), 100, N'9989', N'40564', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00126', CAST(N'2024-02-16T00:00:00' AS SmallDateTime), 160, N'20482', N'40521', N'S02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00127', CAST(N'2024-02-22T00:00:00' AS SmallDateTime), 200, N'9517', N'40711', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00128', CAST(N'2019-02-23T00:00:00' AS SmallDateTime), 130, N'9989', N'40521', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00129', CAST(N'2024-02-25T00:00:00' AS SmallDateTime), 0, N'21151', N'40821', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00130', CAST(N'2019-02-26T00:00:00' AS SmallDateTime), 330, N'9881', N'40812', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00131', CAST(N'2024-03-16T00:00:00' AS SmallDateTime), 200, N'9881', N'40896', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00132', CAST(N'2024-03-18T00:00:00' AS SmallDateTime), 400, N'20503', N'40581', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00133', CAST(N'2024-03-18T00:00:00' AS SmallDateTime), 130, N'20503', N'40714', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00134', CAST(N'2024-03-24T00:00:00' AS SmallDateTime), 500, N'9989', N'40552', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00135', CAST(N'2024-03-30T00:00:00' AS SmallDateTime), 100, N'9517', N'40921', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00136', CAST(N'2024-03-31T00:00:00' AS SmallDateTime), 160, N'20417', N'40123', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00137', CAST(N'2024-03-31T00:00:00' AS SmallDateTime), 220, N'20417', N'40125', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00138', CAST(N'2024-04-02T00:00:00' AS SmallDateTime), 150, N'9881', N'40821', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00139', CAST(N'2024-04-09T00:00:00' AS SmallDateTime), 160, N'20482', N'40561', N'S02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00140', CAST(N'2024-04-09T00:00:00' AS SmallDateTime), 170, N'9881', N'40897', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00141', CAST(N'2024-04-15T00:00:00' AS SmallDateTime), 100, N'9989', N'40323', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00142', CAST(N'2024-04-15T00:00:00' AS SmallDateTime), 250, N'20557', N'40922', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00143', CAST(N'2024-04-20T00:00:00' AS SmallDateTime), 200, N'20181', N'40321', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00144', CAST(N'2024-04-20T00:00:00' AS SmallDateTime), 100, N'8864', N'40561', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00145', CAST(N'2024-04-22T00:00:00' AS SmallDateTime), 500, N'20181', N'40633', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00146', CAST(N'2024-04-22T00:00:00' AS SmallDateTime), 250, N'20417', N'40923', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00147', CAST(N'2024-04-22T00:00:00' AS SmallDateTime), 100, N'20309', N'40323', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00148', CAST(N'2024-04-26T00:00:00' AS SmallDateTime), 120, N'20557', N'40923', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00149', CAST(N'2024-04-27T00:00:00' AS SmallDateTime), 120, N'20482', N'40562', N'S02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00150', CAST(N'2024-04-27T00:00:00' AS SmallDateTime), 370, N'20503', N'40451', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00151', CAST(N'2024-04-27T00:00:00' AS SmallDateTime), 200, N'20493', N'40454', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00152', CAST(N'2024-04-27T00:00:00' AS SmallDateTime), 160, N'9517', N'40923', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00153', CAST(N'2024-04-27T00:00:00' AS SmallDateTime), 250, N'21151', N'40811', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00154', CAST(N'2024-04-29T00:00:00' AS SmallDateTime), 350, N'20512', N'40325', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00155', CAST(N'2024-04-29T00:00:00' AS SmallDateTime), 100, N'20506', N'40252', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00156', CAST(N'2024-05-03T00:00:00' AS SmallDateTime), 190, N'20181', N'40452', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00157', CAST(N'2024-05-04T00:00:00' AS SmallDateTime), 350, N'9517', N'40924', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00158', CAST(N'2024-05-04T00:00:00' AS SmallDateTime), 200, N'21133', N'40569', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00159', CAST(N'2024-05-05T00:00:00' AS SmallDateTime), 350, N'20512', N'40322', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00160', CAST(N'2024-05-07T00:00:00' AS SmallDateTime), 260, N'20557', N'40924', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00161', CAST(N'2024-05-10T00:00:00' AS SmallDateTime), 0, N'8864', N'40569', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00162', CAST(N'2024-05-11T00:00:00' AS SmallDateTime), 150, N'20503', N'40633', N'N01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00163', CAST(N'2024-05-12T00:00:00' AS SmallDateTime), 250, N'9881', N'40890', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00164', CAST(N'2024-05-13T00:00:00' AS SmallDateTime), 500, N'20181', N'40321', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00165', CAST(N'2024-05-14T00:00:00' AS SmallDateTime), 180, N'9881', N'40829', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00166', CAST(N'2024-05-19T00:00:00' AS SmallDateTime), 330, N'9881', N'40821', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00167', CAST(N'2024-05-19T00:00:00' AS SmallDateTime), 100, N'9881', N'40819', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00168', CAST(N'2024-05-21T00:00:00' AS SmallDateTime), 250, N'20417', N'40890', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00169', CAST(N'2024-05-21T00:00:00' AS SmallDateTime), 500, N'21133', N'40552', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00170', CAST(N'2024-05-24T00:00:00' AS SmallDateTime), 150, N'20181', N'40561', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00171', CAST(N'2024-05-24T00:00:00' AS SmallDateTime), 110, N'9517', N'40926', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00172', CAST(N'2024-05-26T00:00:00' AS SmallDateTime), 220, N'20181', N'40322', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00173', CAST(N'2024-05-26T00:00:00' AS SmallDateTime), 100, N'9989', N'40569', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00174', CAST(N'2024-05-27T00:00:00' AS SmallDateTime), 160, N'21151', N'40893', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00175', CAST(N'2024-05-28T00:00:00' AS SmallDateTime), 200, N'9881', N'40893', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00176', CAST(N'2024-05-28T00:00:00' AS SmallDateTime), 120, N'9517', N'40457', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00177', CAST(N'2024-05-28T00:00:00' AS SmallDateTime), 190, N'9881', N'40812', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00178', CAST(N'2024-05-28T00:00:00' AS SmallDateTime), 400, N'20417', N'40624', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00179', CAST(N'2024-06-01T00:00:00' AS SmallDateTime), 500, N'9989', N'40890', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00180', CAST(N'2024-06-02T00:00:00' AS SmallDateTime), 250, N'9517', N'40890', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00181', CAST(N'2024-06-03T00:00:00' AS SmallDateTime), 170, N'9881', N'40895', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00182', CAST(N'2024-06-07T00:00:00' AS SmallDateTime), 110, N'9989', N'40527', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00183', CAST(N'2024-06-09T00:00:00' AS SmallDateTime), 140, N'20181', N'40325', N'E02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00184', CAST(N'2024-06-11T00:00:00' AS SmallDateTime), 0, N'9517', N'40363', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00185', CAST(N'2024-06-11T00:00:00' AS SmallDateTime), 250, N'20417', N'40122', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00186', CAST(N'2024-06-11T00:00:00' AS SmallDateTime), 120, N'20557', N'40921', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00187', CAST(N'2024-06-11T00:00:00' AS SmallDateTime), 100, N'9989', N'40553', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00188', CAST(N'2019-06-14T00:00:00' AS SmallDateTime), 330, N'9881', N'40890', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00189', CAST(N'2024-06-15T00:00:00' AS SmallDateTime), 500, N'9517', N'40896', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00190', CAST(N'2024-06-15T00:00:00' AS SmallDateTime), 170, N'20309', N'40890', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00191', CAST(N'2024-06-22T00:00:00' AS SmallDateTime), 500, N'9517', N'40361', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00192', CAST(N'2024-06-22T00:00:00' AS SmallDateTime), 220, N'20330', N'40893', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00193', CAST(N'2024-06-22T00:00:00' AS SmallDateTime), 110, N'20330', N'40121', N'S03')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00194', CAST(N'2024-06-22T00:00:00' AS SmallDateTime), 100, N'20309', N'40890', N'S01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00195', CAST(N'2024-06-28T00:00:00' AS SmallDateTime), 100, N'9989', N'40561', N'N02')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00196', CAST(N'2024-06-29T00:00:00' AS SmallDateTime), 100, N'9881', N'40829', N'E01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00197', CAST(N'2024-06-29T00:00:00' AS SmallDateTime), 190, N'20417', N'40454', N'W01')
INSERT [dbo].[Sales] ([ordnum], [sldate], [qty], [custnum], [partnum], [repid]) VALUES (N'00198', CAST(N'2024-06-29T00:00:00' AS SmallDateTime), 190, N'20417', N'40457', N'W01')
GO
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'E01', N'Kent      ', N'Allard              ', 0.05)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'E02', N'Margo     ', N'Lane                ', 0.05)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'E03', N'Fred      ', N'Bartell             ', 0.02)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'N01', N'Richard   ', N'Gibson              ', 0.03)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'N02', N'Pat       ', N'Powell              ', 0.03)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'S01', N'George    ', N'Cranston            ', 0.04)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'S02', N'Amelia    ', N'Rose                ', 0.05)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'S03', N'Charlotte ', N'Matthews            ', 0.04)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'W01', N'Anna      ', N'Nolan               ', 0.02)
INSERT [dbo].[Slspers] ([repid], [fname], [lname], [commrate]) VALUES (N'W02', N'Anne      ', N'Green               ', 0.04)
GO
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39843', N'Clear Cupboards                         ', 15055.5000, 49.9500, CAST(N'2023-08-19T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'39905', N'Developing Mobile Apps', 19990.0000, 45.0000, CAST(N'2024-01-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40121', N'Boating Safety                          ', 15421.8100, 36.5000, CAST(N'2024-05-18T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40122', N'Sailing                                 ', 9932.9600, 29.1500, CAST(N'2024-05-03T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40123', N'The Sport of Windsurfing                ', 12798.3200, 38.5000, CAST(N'2023-07-13T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40124', N'The Sport of Hang Gliding               ', 15421.8100, 49.6800, CAST(N'2024-01-06T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40125', N'The Complete Football Reference         ', 15032.4100, 49.9900, CAST(N'2023-08-03T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40231', N'How to Play Piano (Beginner)            ', 9917.7500, 25.0000, CAST(N'2023-06-11T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40232', N'How to Play Piano (Intermediate)        ', 8565.3500, 20.5000, CAST(N'2023-10-22T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40233', N'How to Play Piano (Advanced)            ', 7971.0200, 20.5000, CAST(N'2023-12-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40234', N'How to Play Piano (Professional)        ', 9901.4200, 25.0000, CAST(N'2018-11-13T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40251', N'How to Play Guitar (Beginner)           ', 9727.8000, 25.0000, CAST(N'2023-09-14T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40252', N'How to Play Guitar (Intermediate)       ', 8862.9500, 20.5000, CAST(N'2023-10-26T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40253', N'How to Play Guitar (Advanced)           ', 8355.5000, 20.5000, CAST(N'2023-12-30T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40254', N'How to Play Guitar (Professional)       ', 9704.7100, 25.0000, CAST(N'2024-01-28T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40321', N'Starting a Small Garden                 ', 12369.6700, 35.0000, CAST(N'2024-03-24T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40322', N'Starting a Greenhouse                   ', 11424.1400, 30.5000, CAST(N'2024-05-05T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40323', N'Flower Arranging                        ', 7366.4600, 20.0000, CAST(N'2024-03-30T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40324', N'The Complete Guide to Flowers           ', 9185.3100, 24.9500, CAST(N'2024-02-05T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40325', N'The Complete Guide to Vegetables        ', 9709.2000, 24.9500, CAST(N'2024-03-10T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40326', N'English Gardens                         ', 15998.0000, 40.0000, CAST(N'2023-08-03T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40361', N'Landscaping (Beginner)                  ', 12933.5300, 30.0000, CAST(N'2024-03-12T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40363', N'Landscaping (Advanced)                  ', 12336.4200, 25.0000, CAST(N'2024-03-22T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40364', N'Landscaping (Professional)              ', 13445.6200, 30.0000, CAST(N'2024-04-05T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40451', N'Plumbing Repairs Made Easy              ', 15179.7500, 40.2500, CAST(N'2023-08-28T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40452', N'Woodworking Around the House            ', 14385.7300, 46.9700, CAST(N'2024-04-23T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40453', N'Wallpapering Made Easy                  ', 9931.0300, 25.5000, CAST(N'2024-02-16T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40454', N'Minor Home Repairs Made Easy            ', 13258.8900, 45.9500, CAST(N'2024-01-28T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40455', N'More Home Repairs Made Easy             ', 14737.1000, 49.9900, CAST(N'2024-04-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40457', N'Basic Home Electronics                  ', 9274.1700, 32.2900, CAST(N'2023-10-23T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40458', N'Modern Architecture                     ', 12268.2600, 39.9900, CAST(N'2023-09-15T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40471', N'Guide to Stereo Equipment               ', 13825.2600, 39.9800, CAST(N'2023-08-20T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40472', N'Guide to Video Equipment                ', 12845.3000, 39.9800, CAST(N'2023-09-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40481', N'Simple Auto Repairs                     ', NULL, 39.9900, CAST(N'2023-06-29T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40482', N'The Complete Auto Repair Guide          ', 16022.4900, 50.9900, CAST(N'2018-07-22T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40521', N'Creating Toys in Wood                   ', 9445.0700, 23.7900, CAST(N'2024-12-04T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40522', N'Cross-stitching for Special Occasions   ', 8102.4800, 20.0000, CAST(N'2023-10-30T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40526', N'Furniture Refinishing                   ', 11642.9500, 39.9900, CAST(N'2024-01-12T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40527', N'Furniture Upholstery                    ', 13136.2600, 46.9500, CAST(N'2024-06-24T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40551', N'The Art of Water Painting               ', 11155.9800, 34.5000, CAST(N'2024-01-06T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40552', N'The Art of Oil Painting                 ', 11277.5600, 34.5000, CAST(N'2024-03-17T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40553', N'The Art of Pen and Ink Drawing          ', 11368.8800, 34.5000, CAST(N'2024-04-29T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40561', N'All Kinds of Knitting                   ', 10075.9800, 26.9800, CAST(N'2024-04-16T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40562', N'Learning to Crochet                     ', 10001.1400, 30.7500, CAST(N'2023-07-31T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40563', N'Stencil the Room                 ', 8812.4000, 15.5000, CAST(N'2024-02-03T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40564', N'Macrame Made Easy                       ', 7520.2700, 20.0000, CAST(N'2023-08-31T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40569', N'Calligraphy                             ', 8973.4300, 25.2500, CAST(N'2024-05-03T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40581', N'Unique Picture Framing                  ', 11235.9500, 34.5000, CAST(N'2023-07-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40611', N'Learning Italian (Beginner)             ', 9604.6200, 30.0000, CAST(N'2024-12-18T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40612', N'Learning Italian (Intermediate)         ', 9728.8500, 30.0000, CAST(N'2024-02-04T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40613', N'Learning Italian (Advanced)             ', 9941.7100, 30.0000, CAST(N'2024-04-21T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40614', N'Conversational Italian                  ', 11014.8100, 35.0000, CAST(N'2023-06-11T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40621', N'Learning German (Beginner)              ', 9697.0900, 30.0000, CAST(N'2024-10-29T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40622', N'Learning German (Intermediate)          ', 9990.8300, 30.0000, CAST(N'2024-01-26T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40623', N'Learning German (Advanced)              ', 9850.6100, 30.0000, CAST(N'2019-04-22T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40624', N'Conversational German                   ', 9972.8900, 35.0000, CAST(N'2024-05-28T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40631', N'Learning French (Beginner)              ', 9008.0800, 30.0000, CAST(N'2023-11-04T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40632', N'Learning French (Intermediate)          ', 9469.7900, 30.0000, CAST(N'2023-12-11T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40633', N'Learning French (Advanced)              ', 9805.9800, 30.0000, CAST(N'2024-03-31T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40634', N'Conversational French                   ', 10905.3000, 35.0000, CAST(N'2024-05-20T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40641', N'Learning Japanese (Beginner)            ', 9875.5200, 30.0000, CAST(N'2023-07-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40642', N'Learning Japanese (Intermediate)        ', 9753.6600, 30.0000, CAST(N'2023-09-15T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40643', N'Learning Japanese (Advanced)            ', NULL, 30.0000, CAST(N'2023-11-20T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40644', N'Conversational Japanese                 ', NULL, 35.0000, CAST(N'2024-02-11T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40651', N'Learning Chinese (Beginner)             ', 9557.8100, 30.0000, CAST(N'2023-07-20T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40652', N'Learning Chinese (Intermediate)         ', 9789.2300, 30.0000, CAST(N'2023-11-11T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40653', N'Learning Chinese (Advanced)             ', NULL, 30.0000, CAST(N'2024-02-26T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40654', N'Conversational Chinese                  ', 0.0000, 35.0000, CAST(N'2024-04-29T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40711', N'Recipes From Italy                      ', 11772.7300, 39.9900, CAST(N'2023-09-02T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40712', N'Recipes From India                      ', 11105.1500, 38.8900, CAST(N'2023-08-19T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40713', N'Decorating Wedding Cakes                ', 13166.8800, 44.4500, CAST(N'2023-07-29T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40714', N'Chocolate Lovers Cookbook               ', 9557.4100, 25.9500, CAST(N'2023-08-03T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40811', N'Understanding Geometry                  ', 11056.4400, 35.7500, CAST(N'2024-03-15T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40812', N'Understanding Trigonometry              ', 12294.0300, 35.7500, CAST(N'2024-02-24T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40819', N'Quick Study in Calculus                 ', 8508.4300, 21.9500, CAST(N'2024-04-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40821', N'Understanding Physics                   ', 12933.1900, 42.9800, CAST(N'2024-02-24T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40822', N'Understanding Biology                   ', 12675.5000, 35.7300, CAST(N'2024-02-24T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40829', N'Quick Study in English Grammar          ', 7980.0000, 21.9500, CAST(N'2024-05-10T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40890', N'The Mayan Civilization                  ', 13409.4400, 39.9900, CAST(N'2024-05-18T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40891', N'Writing the Great American Novel        ', NULL, 44.5000, CAST(N'2024-05-25T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40892', N'How to Manage Money Effectively         ', 13929.7500, 44.5000, CAST(N'2024-05-25T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40893', N'North American History                  ', 16349.9400, 50.0000, CAST(N'2023-05-27T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40894', N'Studying the Civil War                  ', 15301.4100, 47.9900, CAST(N'2024-08-05T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40895', N'The History of Baseball                 ', 13187.0600, 69.9900, CAST(N'2024-04-01T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40896', N'Studying Greek Mythology                ', 11259.3400, 27.9500, CAST(N'2024-03-02T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40897', N'Mythologies of the World                ', 15714.0200, 49.9500, CAST(N'2024-04-06T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40921', N'Taking Care of Your Dog                 ', 8808.7400, 13.9900, CAST(N'2024-03-29T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40922', N'Taking Care of Your Hamster             ', 7260.7300, 13.9900, CAST(N'2024-03-24T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40923', N'Taking Care of Your Fish                ', 9200.6000, 13.9900, CAST(N'2024-04-12T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40924', N'Taking Care of Your Cat                 ', 9580.8000, 13.9900, CAST(N'2024-04-26T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40925', N'Taking Care of Your Rabbit              ', 8255.6200, 13.9900, CAST(N'2024-05-19T00:00:00' AS SmallDateTime))
INSERT [dbo].[Titles] ([partnum], [bktitle], [devcost], [slprice], [pubdate]) VALUES (N'40926', N'Taking Care of Your Parrot              ', 9904.7000, 13.9900, CAST(N'2024-05-20T00:00:00' AS SmallDateTime))
GO
