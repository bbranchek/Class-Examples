import multiprocessing
import tkinter as tk
import time

def cpu_worker(core_id, queue):
    """
    A simple loop that runs on an individual CPU core.
    """
    counter = 0
    while True:
        # Simulate light CPU work
        for _ in range(100_000):
            counter += 1
        
        # Send the updated count to the UI process
        queue.put((core_id, counter))
        
        # Slight pause so the UI queue doesn't get flooded too fast
        time.sleep(0.05)

class MultiCoreMonitor:
    def __init__(self, root, num_cores=12):
        self.root = root
        self.num_cores = num_cores
        self.root.title("12-Core Loop Monitor")
        self.root.geometry("450x350")
        self.root.resizable(False, False)
        
        self.queue = multiprocessing.Queue()
        self.processes = []
        self.labels = []

        # Create a 6x2 grid of labels for the 12 cores
        for i in range(self.num_cores):
            frame = tk.Frame(root, bd=1, relief="solid", padx=10, pady=10)
            frame.grid(row=i // 2, column=i % 2, padx=10, pady=5, sticky="ew")
            
            lbl = tk.Label(frame, text=f"Core {i + 1:02d}: Starting...", font=("Consolas", 11))
            lbl.pack()
            self.labels.append(lbl)

        # Make columns expand evenly
        root.grid_columnconfigure(0, weight=1)
        root.grid_columnconfigure(1, weight=1)

        # Start the worker processes
        for i in range(self.num_cores):
            p = multiprocessing.Process(target=cpu_worker, args=(i, self.queue))
            p.daemon = True  # Ensures processes close if the main program crashes
            p.start()
            self.processes.append(p)

        # Handle window close cleanly
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # Start checking the queue for UI updates
        self.update_ui()

    def update_ui(self):
        # Pull all pending updates from the queue
        while not self.queue.empty():
            try:
                core_id, count = self.queue.get_nowait()
                self.labels[core_id].config(text=f"Core {core_id + 1:02d}: {count:,}")
            except Exception:
                break
        
        # Schedule the next UI refresh in 50 milliseconds
        self.root.after(50, self.update_ui)

    def on_close(self):
        # Terminate all background core processes before closing the window
        for p in self.processes:
            p.terminate()
        self.root.destroy()

if __name__ == "__main__":
    # Required for Windows multiprocessing
    multiprocessing.freeze_support()
    
    root = tk.Tk()
    app = MultiCoreMonitor(root, num_cores=12)
    root.mainloop()
