import multiprocessing
import os
import platform
import re
import subprocess
import time
import winreg


def get_windows_cpu_details():
  cpu_name = "Unknown"
  stepping = "Unknown"
  base_mhz = "Unknown"
  architecture = platform.machine()

  try:
    key_path = r"HARDWARE\DESCRIPTION\System\CentralProcessor\0"
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as key:
      cpu_name, _ = winreg.QueryValueEx(key, "ProcessorNameString")
      identifier, _ = winreg.QueryValueEx(key, "Identifier")
      base_mhz, _ = winreg.QueryValueEx(key, "~MHz")

      match = re.search(r"Stepping\s+(\d+)", identifier, re.IGNORECASE)
      if match:
        stepping = match.group(1)
  except Exception as e:
    print(f"Registry read error: {e}")

  logical_cores = os.cpu_count()
  physical_cores = 1
  l2_cache = "Unknown"
  l3_cache = "Unknown"

  try:
    ps_cmd = (
        "Get-CimInstance Win32_Processor | "
        "Select-Object NumberOfCores, L2CacheSize, L3CacheSize | "
        "ConvertTo-Csv -NoTypeInformation"
    )
    output = (
        subprocess.check_output(["powershell", "-Command", ps_cmd], text=True)
        .strip()
        .splitlines()
    )

    if len(output) >= 2:
      values = [val.strip('"') for val in output[1].split(",")]
      physical_cores = int(values[0])
      l2_cache = f"{values[1]} KB"
      l3_cache = f"{values[2]} KB"
  except Exception:
    pass

  return {
      "name": cpu_name.strip(),
      "arch": architecture,
      "stepping": stepping,
      "base_mhz": base_mhz,
      "physical_cores": physical_cores,
      "logical_cores": logical_cores,
      "l2_cache": l2_cache,
      "l3_cache": l3_cache,
  }


def core_worker(worker_id, barrier, active_counter, lock, run_seconds=5):
  # 1. Wait until ALL physical core workers have finished spawning on Windows
  barrier.wait()

  # 2. Register this core as actively running
  with lock:
    active_counter.value += 1

  # 3. Run a continuous CPU loop for the specified duration
  end_time = time.perf_counter() + run_seconds
  total = 0
  while time.perf_counter() < end_time:
    for i in range(100_000):
      total += i % 7

  # 4. Unregister when finished
  with lock:
    active_counter.value -= 1

  return worker_id, total


if __name__ == "__main__":
  multiprocessing.freeze_support()

  if platform.system() != "Windows":
    print("This script is designed for Windows systems.")
    exit(1)

  details = get_windows_cpu_details()
  num_physical = details["physical_cores"]

  print(f"Processor Designation: {details['name']}")
  print(f"Architecture:          {details['arch']}")
  print(f"Processor Stepping:    {details['stepping']}")
  print(f"Base Clock Speed:      {details['base_mhz']} MHz")
  print(f"Physical CPU Cores:    {num_physical}")
  print(f"Logical CPU Cores:     {details['logical_cores']}")
  print(f"L2 Cache Size:         {details['l2_cache']}")
  print(f"L3 Cache Size:         {details['l3_cache']}")
  print("-" * 50)

  # Barrier waits for all physical workers + 1 main monitor process
  sync_barrier = multiprocessing.Barrier(num_physical + 1)
  active_cores = multiprocessing.Value("i", 0)
  lock = multiprocessing.Lock()
  processes = []

  print(f"Spawning {num_physical} worker processes...")
  for core_idx in range(num_physical):
    p = multiprocessing.Process(
        target=core_worker,
        args=(core_idx, sync_barrier, active_cores, lock, 5),
    )
    p.start()
    processes.append(p)

  # Wait until all 12 Windows processes are ready before starting the loop
  sync_barrier.wait()
  print("All processes ready! Starting 5-second loop across all cores...")

  # Short delay to let all workers acquire the lock and increment the counter
  time.sleep(0.2)

  max_running = 0
  while any(p.is_alive() for p in processes):
    with lock:
      current = active_cores.value
    if current > max_running:
      max_running = current
    print(
        f"\rCores currently running the loop: {current} / {num_physical}  ",
        end="",
        flush=True,
    )
    time.sleep(0.2)

  for p in processes:
    p.join()

  print(f"\rCores currently running the loop: 0 / {num_physical}  ")
  print(f"Peak simultaneous cores running loop: {max_running} / {num_physical}")
